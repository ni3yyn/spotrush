#!/usr/bin/env python3
"""Idempotently register SpotRush's custom invitation URI in Godot's Android template.

Run after `godot --install-android-build-template` and before Android export.
The script changes only the generated `android/build/AndroidManifest.xml`; it
never edits `export_presets.cfg` or the project source manifest.
"""

from __future__ import annotations

import argparse
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ANDROID_NS = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ANDROID_NS)


def android_attr(name: str) -> str:
    return f"{{{ANDROID_NS}}}{name}"


def is_launcher_activity(element: ET.Element) -> bool:
    if element.tag not in {"activity", "activity-alias"}:
        return False
    for intent_filter in element.findall("intent-filter"):
        actions = {
            action.get(android_attr("name"), "")
            for action in intent_filter.findall("action")
        }
        categories = {
            category.get(android_attr("name"), "")
            for category in intent_filter.findall("category")
        }
        if (
            "android.intent.action.MAIN" in actions
            and "android.intent.category.LAUNCHER" in categories
        ):
            return True
    return False


def has_spotrush_filter(activity: ET.Element) -> bool:
    for intent_filter in activity.findall("intent-filter"):
        actions = {
            action.get(android_attr("name"), "")
            for action in intent_filter.findall("action")
        }
        categories = {
            category.get(android_attr("name"), "")
            for category in intent_filter.findall("category")
        }
        for data in intent_filter.findall("data"):
            if (
                "android.intent.action.VIEW" in actions
                and "android.intent.category.DEFAULT" in categories
                and "android.intent.category.BROWSABLE" in categories
                and data.get(android_attr("scheme")) == "spotrush"
                and data.get(android_attr("host")) == "join"
            ):
                return True
    return False


def patch_manifest(path: Path) -> bool:
    if not path.is_file():
        raise FileNotFoundError(
            f"Android manifest not found: {path}. Install the Godot Android build template first."
        )

    parser = ET.XMLParser()
    tree = ET.parse(path, parser=parser)
    root = tree.getroot()
    launchers = [element for element in root.iter() if is_launcher_activity(element)]
    if len(launchers) != 1:
        raise RuntimeError(
            f"Expected exactly one launcher activity in {path}, found {len(launchers)}. "
            "Refusing to guess which activity should receive the invitation filter."
        )

    activity = launchers[0]
    if has_spotrush_filter(activity):
        print("SpotRush deep-link intent filter already exists; no change needed.")
        return False

    intent_filter = ET.SubElement(activity, "intent-filter")
    ET.SubElement(
        intent_filter,
        "action",
        {android_attr("name"): "android.intent.action.VIEW"},
    )
    ET.SubElement(
        intent_filter,
        "category",
        {android_attr("name"): "android.intent.category.DEFAULT"},
    )
    ET.SubElement(
        intent_filter,
        "category",
        {android_attr("name"): "android.intent.category.BROWSABLE"},
    )
    ET.SubElement(
        intent_filter,
        "data",
        {
            android_attr("scheme"): "spotrush",
            android_attr("host"): "join",
        },
    )

    # The file belongs to Godot's generated template, not to the checked-in
    # project. Reformatting this generated XML is safe and keeps the update
    # deterministic for CI and local builds.
    ET.indent(tree, space="    ")
    tree.write(path, encoding="utf-8", xml_declaration=True)
    print(f"Registered spotrush://join deep links in {path}")
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("android/build/AndroidManifest.xml"),
        help="Path to the generated Godot Android manifest.",
    )
    args = parser.parse_args()
    try:
        patch_manifest(args.manifest)
    except (OSError, ET.ParseError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
